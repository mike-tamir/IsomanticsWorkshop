from distutils.core import setup
setup(
    name="ismtools",
    version="0.1.0",
    packages=['ismtools',],
)
